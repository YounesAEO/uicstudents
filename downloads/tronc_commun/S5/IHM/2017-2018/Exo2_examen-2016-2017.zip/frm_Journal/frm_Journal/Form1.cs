﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_Journal
{
    public partial class Form1 : Form
    {
        double TotalCredit;
        double TotalDebit ;
        double balance;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rbDebit.Checked = true;
            lbCredit.Items.Clear();
            lbDebit.Items.Clear();

        }

        private void btnEcrireJournal_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtMontant.Text))
            {
                MessageBox.Show("Veuillez saisir un montant");
            }
            else
            {
                if(rbDebit.Checked)
                {
                    lbDebit.Items.Add(double.Parse(txtMontant.Text));
                    lbCredit.Items.Add(0);
                    TotalDebit += double.Parse(txtMontant.Text);
                    balance -= double.Parse(txtMontant.Text);
                    txtDebit.Text = Convert.ToString(TotalDebit);
                    txtBalance.Text = Convert.ToString(balance);
                }
                else
                {
                    lbCredit.Items.Add(int.Parse(txtMontant.Text));
                    lbDebit.Items.Add(0);
                    TotalCredit += int.Parse(txtMontant.Text);
                    balance += double.Parse(txtMontant.Text);
                    txtCredit.Text = Convert.ToString(TotalCredit);
                    txtBalance.Text = Convert.ToString(balance);
                }
            }
        }

        private void txtCredit_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            int count = lbCredit.Items.Count;
            TotalCredit -= double.Parse(lbCredit.Items[count - 1].ToString());
            txtCredit.Text = Convert.ToString(TotalCredit);
            balance -= double.Parse(lbCredit.Items[count - 1].ToString());
            TotalDebit += double.Parse(lbDebit.Items[count - 1].ToString());
            txtDebit.Text = Convert.ToString(TotalDebit);
            balance += double.Parse(lbDebit.Items[count - 1].ToString());
            lbCredit.Items.RemoveAt(lbCredit.Items.Count-1);
            lbDebit.Items.RemoveAt(lbDebit.Items.Count-1);
            txtBalance.Text = Convert.ToString(balance);
        }
    }
}
