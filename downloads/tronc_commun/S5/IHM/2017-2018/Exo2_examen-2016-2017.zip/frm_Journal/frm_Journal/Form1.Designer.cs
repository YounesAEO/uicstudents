﻿namespace frm_Journal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtMontant = new System.Windows.Forms.TextBox();
            this.rbCredit = new System.Windows.Forms.RadioButton();
            this.rbDebit = new System.Windows.Forms.RadioButton();
            this.btnEcrireJournal = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.lbCredit = new System.Windows.Forms.ListBox();
            this.lbDebit = new System.Windows.Forms.ListBox();
            this.lblMontant = new System.Windows.Forms.Label();
            this.lblTypeOperation = new System.Windows.Forms.Label();
            this.lblCreditLB = new System.Windows.Forms.Label();
            this.lblDebitLB = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCredit = new System.Windows.Forms.TextBox();
            this.txtDebit = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblTypeOperation);
            this.groupBox1.Controls.Add(this.lblMontant);
            this.groupBox1.Controls.Add(this.rbDebit);
            this.groupBox1.Controls.Add(this.rbCredit);
            this.groupBox1.Controls.Add(this.txtMontant);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 162);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Saisie des données";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnQuitter);
            this.groupBox2.Controls.Add(this.btnAnnuler);
            this.groupBox2.Controls.Add(this.btnEcrireJournal);
            this.groupBox2.Location = new System.Drawing.Point(319, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(290, 161);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Opérations";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtBalance);
            this.groupBox3.Controls.Add(this.txtDebit);
            this.groupBox3.Controls.Add(this.txtCredit);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.lblDebitLB);
            this.groupBox3.Controls.Add(this.lblCreditLB);
            this.groupBox3.Controls.Add(this.lbDebit);
            this.groupBox3.Controls.Add(this.lbCredit);
            this.groupBox3.Location = new System.Drawing.Point(13, 180);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(596, 181);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Journal des écritures";
            // 
            // txtMontant
            // 
            this.txtMontant.Location = new System.Drawing.Point(107, 31);
            this.txtMontant.Name = "txtMontant";
            this.txtMontant.Size = new System.Drawing.Size(100, 20);
            this.txtMontant.TabIndex = 0;
            // 
            // rbCredit
            // 
            this.rbCredit.AutoSize = true;
            this.rbCredit.Location = new System.Drawing.Point(107, 73);
            this.rbCredit.Name = "rbCredit";
            this.rbCredit.Size = new System.Drawing.Size(52, 17);
            this.rbCredit.TabIndex = 1;
            this.rbCredit.TabStop = true;
            this.rbCredit.Text = "Crédit";
            this.rbCredit.UseVisualStyleBackColor = true;
            // 
            // rbDebit
            // 
            this.rbDebit.AutoSize = true;
            this.rbDebit.Location = new System.Drawing.Point(107, 96);
            this.rbDebit.Name = "rbDebit";
            this.rbDebit.Size = new System.Drawing.Size(50, 17);
            this.rbDebit.TabIndex = 2;
            this.rbDebit.TabStop = true;
            this.rbDebit.Text = "Débit";
            this.rbDebit.UseVisualStyleBackColor = true;
            // 
            // btnEcrireJournal
            // 
            this.btnEcrireJournal.Location = new System.Drawing.Point(45, 30);
            this.btnEcrireJournal.Name = "btnEcrireJournal";
            this.btnEcrireJournal.Size = new System.Drawing.Size(167, 23);
            this.btnEcrireJournal.TabIndex = 0;
            this.btnEcrireJournal.Text = "Écrire dans le journal";
            this.btnEcrireJournal.UseVisualStyleBackColor = true;
            this.btnEcrireJournal.Click += new System.EventHandler(this.btnEcrireJournal_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(45, 72);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(167, 23);
            this.btnAnnuler.TabIndex = 1;
            this.btnAnnuler.Text = "Annuler la dernière écriture";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // btnQuitter
            // 
            this.btnQuitter.Location = new System.Drawing.Point(45, 116);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(167, 23);
            this.btnQuitter.TabIndex = 2;
            this.btnQuitter.Text = "Quitter l\'application";
            this.btnQuitter.UseVisualStyleBackColor = true;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // lbCredit
            // 
            this.lbCredit.FormattingEnabled = true;
            this.lbCredit.Location = new System.Drawing.Point(106, 34);
            this.lbCredit.Name = "lbCredit";
            this.lbCredit.Size = new System.Drawing.Size(120, 95);
            this.lbCredit.TabIndex = 0;
            // 
            // lbDebit
            // 
            this.lbDebit.FormattingEnabled = true;
            this.lbDebit.Location = new System.Drawing.Point(279, 34);
            this.lbDebit.Name = "lbDebit";
            this.lbDebit.Size = new System.Drawing.Size(120, 95);
            this.lbDebit.TabIndex = 1;
            // 
            // lblMontant
            // 
            this.lblMontant.AutoSize = true;
            this.lblMontant.Location = new System.Drawing.Point(10, 34);
            this.lblMontant.Name = "lblMontant";
            this.lblMontant.Size = new System.Drawing.Size(46, 13);
            this.lblMontant.TabIndex = 3;
            this.lblMontant.Text = "Montant";
            // 
            // lblTypeOperation
            // 
            this.lblTypeOperation.AutoSize = true;
            this.lblTypeOperation.Location = new System.Drawing.Point(10, 73);
            this.lblTypeOperation.Name = "lblTypeOperation";
            this.lblTypeOperation.Size = new System.Drawing.Size(86, 13);
            this.lblTypeOperation.TabIndex = 4;
            this.lblTypeOperation.Text = "Type d\'opération";
            // 
            // lblCreditLB
            // 
            this.lblCreditLB.AutoSize = true;
            this.lblCreditLB.Location = new System.Drawing.Point(106, 15);
            this.lblCreditLB.Name = "lblCreditLB";
            this.lblCreditLB.Size = new System.Drawing.Size(34, 13);
            this.lblCreditLB.TabIndex = 2;
            this.lblCreditLB.Text = "Crédit";
            // 
            // lblDebitLB
            // 
            this.lblDebitLB.AutoSize = true;
            this.lblDebitLB.Location = new System.Drawing.Point(279, 15);
            this.lblDebitLB.Name = "lblDebitLB";
            this.lblDebitLB.Size = new System.Drawing.Size(32, 13);
            this.lblDebitLB.TabIndex = 3;
            this.lblDebitLB.Text = "Débit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Total";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Balance";
            // 
            // txtCredit
            // 
            this.txtCredit.Enabled = false;
            this.txtCredit.Location = new System.Drawing.Point(106, 147);
            this.txtCredit.Name = "txtCredit";
            this.txtCredit.Size = new System.Drawing.Size(100, 20);
            this.txtCredit.TabIndex = 6;
            this.txtCredit.TextChanged += new System.EventHandler(this.txtCredit_TextChanged);
            // 
            // txtDebit
            // 
            this.txtDebit.Enabled = false;
            this.txtDebit.Location = new System.Drawing.Point(279, 146);
            this.txtDebit.Name = "txtDebit";
            this.txtDebit.Size = new System.Drawing.Size(100, 20);
            this.txtDebit.TabIndex = 7;
            // 
            // txtBalance
            // 
            this.txtBalance.Enabled = false;
            this.txtBalance.Location = new System.Drawing.Point(408, 146);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(100, 20);
            this.txtBalance.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(652, 373);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblTypeOperation;
        private System.Windows.Forms.Label lblMontant;
        private System.Windows.Forms.RadioButton rbDebit;
        private System.Windows.Forms.RadioButton rbCredit;
        private System.Windows.Forms.TextBox txtMontant;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Button btnEcrireJournal;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtDebit;
        private System.Windows.Forms.TextBox txtCredit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDebitLB;
        private System.Windows.Forms.Label lblCreditLB;
        private System.Windows.Forms.ListBox lbDebit;
        private System.Windows.Forms.ListBox lbCredit;
    }
}

