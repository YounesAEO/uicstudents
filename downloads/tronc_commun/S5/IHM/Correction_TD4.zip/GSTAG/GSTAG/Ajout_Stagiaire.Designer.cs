﻿namespace GSTAG
{
    partial class Ajout_Stagiaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInscription = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.lblSexe = new System.Windows.Forms.Label();
            this.lblNaissance = new System.Windows.Forms.Label();
            this.lblModule = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.txtInscription = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.rbFeminin = new System.Windows.Forms.RadioButton();
            this.fbMasculin = new System.Windows.Forms.RadioButton();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.cbModule = new System.Windows.Forms.ComboBox();
            this.dtpNaissance = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lblInscription
            // 
            this.lblInscription.AutoSize = true;
            this.lblInscription.Location = new System.Drawing.Point(30, 54);
            this.lblInscription.Name = "lblInscription";
            this.lblInscription.Size = new System.Drawing.Size(77, 13);
            this.lblInscription.TabIndex = 0;
            this.lblInscription.Text = "N° d\'inscription";
            this.lblInscription.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(30, 80);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(29, 13);
            this.lblNom.TabIndex = 1;
            this.lblNom.Text = "Nom";
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.Location = new System.Drawing.Point(30, 105);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(43, 13);
            this.lblPrenom.TabIndex = 2;
            this.lblPrenom.Text = "Prénom";
            // 
            // lblSexe
            // 
            this.lblSexe.AutoSize = true;
            this.lblSexe.Location = new System.Drawing.Point(30, 131);
            this.lblSexe.Name = "lblSexe";
            this.lblSexe.Size = new System.Drawing.Size(31, 13);
            this.lblSexe.TabIndex = 3;
            this.lblSexe.Text = "Sexe";
            // 
            // lblNaissance
            // 
            this.lblNaissance.AutoSize = true;
            this.lblNaissance.Location = new System.Drawing.Point(30, 162);
            this.lblNaissance.Name = "lblNaissance";
            this.lblNaissance.Size = new System.Drawing.Size(96, 13);
            this.lblNaissance.TabIndex = 4;
            this.lblNaissance.Text = "Date de naissance";
            // 
            // lblModule
            // 
            this.lblModule.AutoSize = true;
            this.lblModule.Location = new System.Drawing.Point(30, 194);
            this.lblModule.Name = "lblModule";
            this.lblModule.Size = new System.Drawing.Size(42, 13);
            this.lblModule.TabIndex = 5;
            this.lblModule.Text = "Module";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(30, 227);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(30, 13);
            this.lblNote.TabIndex = 6;
            this.lblNote.Text = "Note";
            // 
            // txtInscription
            // 
            this.txtInscription.Location = new System.Drawing.Point(156, 51);
            this.txtInscription.Name = "txtInscription";
            this.txtInscription.Size = new System.Drawing.Size(82, 20);
            this.txtInscription.TabIndex = 7;
            // 
            // txtNom
            // 
            this.txtNom.Location = new System.Drawing.Point(156, 77);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(189, 20);
            this.txtNom.TabIndex = 8;
            this.txtNom.TextChanged += new System.EventHandler(this.txtNom_TextChanged);
            // 
            // txtPrenom
            // 
            this.txtPrenom.Location = new System.Drawing.Point(156, 102);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(189, 20);
            this.txtPrenom.TabIndex = 9;
            // 
            // rbFeminin
            // 
            this.rbFeminin.AutoSize = true;
            this.rbFeminin.Checked = true;
            this.rbFeminin.Location = new System.Drawing.Point(156, 129);
            this.rbFeminin.Name = "rbFeminin";
            this.rbFeminin.Size = new System.Drawing.Size(61, 17);
            this.rbFeminin.TabIndex = 10;
            this.rbFeminin.TabStop = true;
            this.rbFeminin.Text = "Féminin";
            this.rbFeminin.UseVisualStyleBackColor = true;
            // 
            // fbMasculin
            // 
            this.fbMasculin.AutoSize = true;
            this.fbMasculin.Location = new System.Drawing.Point(251, 129);
            this.fbMasculin.Name = "fbMasculin";
            this.fbMasculin.Size = new System.Drawing.Size(67, 17);
            this.fbMasculin.TabIndex = 11;
            this.fbMasculin.TabStop = true;
            this.fbMasculin.Text = "Masculin";
            this.fbMasculin.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(115, 280);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(91, 24);
            this.btnOK.TabIndex = 12;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(251, 275);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(94, 24);
            this.btnAnnuler.TabIndex = 13;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(156, 224);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(58, 20);
            this.txtNote.TabIndex = 14;
            // 
            // cbModule
            // 
            this.cbModule.FormattingEnabled = true;
            this.cbModule.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.cbModule.Location = new System.Drawing.Point(156, 191);
            this.cbModule.Name = "cbModule";
            this.cbModule.Size = new System.Drawing.Size(63, 21);
            this.cbModule.TabIndex = 15;
            this.cbModule.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dtpNaissance
            // 
            this.dtpNaissance.Location = new System.Drawing.Point(156, 156);
            this.dtpNaissance.Name = "dtpNaissance";
            this.dtpNaissance.Size = new System.Drawing.Size(189, 20);
            this.dtpNaissance.TabIndex = 16;
            // 
            // Ajout_Stagiaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 311);
            this.Controls.Add(this.dtpNaissance);
            this.Controls.Add(this.cbModule);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.fbMasculin);
            this.Controls.Add(this.rbFeminin);
            this.Controls.Add(this.txtPrenom);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.txtInscription);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lblModule);
            this.Controls.Add(this.lblNaissance);
            this.Controls.Add(this.lblSexe);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.lblInscription);
            this.Name = "Ajout_Stagiaire";
            this.Text = "Ajout d\'un stagiaire";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInscription;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.Label lblSexe;
        private System.Windows.Forms.Label lblNaissance;
        private System.Windows.Forms.Label lblModule;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.TextBox txtInscription;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.RadioButton rbFeminin;
        private System.Windows.Forms.RadioButton fbMasculin;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.ComboBox cbModule;
        private System.Windows.Forms.DateTimePicker dtpNaissance;
    }
}