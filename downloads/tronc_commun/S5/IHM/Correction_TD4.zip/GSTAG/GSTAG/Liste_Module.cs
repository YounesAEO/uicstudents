﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSTAG
{
    public partial class Liste_Module : Form
    {
        public Liste_Module()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtModule.Clear();
            foreach (Stagiaire s in Global.lst)
            {
                if (s.Module == int.Parse(comboBox1.Text))
                {
                    txtModule.AppendText(s.Nom + " " + s.Prenom + " " + (s.Sexe).ToString() + " " + (s.Dn).ToString() + " " + (s.Module).ToString() + " " + (s.Note).ToString());
                    txtModule.AppendText(Environment.NewLine);
                }
            }
        }
    }
}
