﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSTAG
{
    public partial class Ajout_Stagiaire : Form
    {
        public Ajout_Stagiaire()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            int num = int.Parse(txtInscription.Text);
            string n = txtNom.Text;
            string p = txtPrenom.Text;
            Genre s = rbFeminin.Checked ? Genre.Feminin : Genre.Masculin;
            DateTime dt = dtpNaissance.Value;
            int m = int.Parse(cbModule.Text);
            float note = float.Parse(txtNote.Text);
            Stagiaire.AjouterStagiaire(num, n, p, s, dt, m, note);
            MessageBox.Show("Enregistrement effectué", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtNom_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
