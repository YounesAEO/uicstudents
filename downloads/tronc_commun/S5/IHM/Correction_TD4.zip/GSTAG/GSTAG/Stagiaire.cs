﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSTAG
{
    public enum Genre
    {
        Masculin, Feminin
    }
    public class Stagiaire
    {
        private int numInsc;
        private string nom;
        private string prenom;
        private Genre sexe;
        private DateTime dn;
        private int module;
        private float note;

        public int NumInsc { get => numInsc; set => numInsc = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public Genre Sexe { get => sexe; set => sexe = value; }
        public DateTime Dn { get => dn; set => dn = value; }
        public int Module { get => module; set => module = value; }
        public float Note { get => note; set => note = value; }

        public static void AjouterStagiaire(int ni, string n,string p, Genre s, DateTime dn, int module, float note)
        {
            Stagiaire S = new Stagiaire();
            S.NumInsc = ni;
            S.Nom = n;
            S.Prenom = p;
            S.Sexe = s;
            S.Dn = dn;
            S.Module = module;
            S.Note = note;
            Global.lst.Add(S);
        }

        public static int ChercherStagiaire(int ni)
        {
            int res = -1;
            foreach(Stagiaire S in Global.lst)
                {
                if (S.NumInsc == ni)
                    res = Global.lst.IndexOf(S);
                }
            return res;
        }

        public static bool SupprimerStagiaire(int ni)
        {
            bool v = false;
            int r = ChercherStagiaire(ni);
            if (r != -1)
            {
                Global.lst.RemoveAt(r);
                v = true;
            }
            return v;
        }

        public static Stagiaire getStagiaireByPosition(int ni)
        {
            int v = ChercherStagiaire(ni);
            Stagiaire S = null;
            if (v != -1)
                S = Global.lst[v];
            return S;

        }
    }
}
