﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSTAG
{
    public partial class Supprimer_Stagiaire : Form
    {
        public Supprimer_Stagiaire()
        {
            InitializeComponent();
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            int v = Stagiaire.ChercherStagiaire(int.Parse(txtInscription.Text));
            if (v == -1)
            {
                MessageBox.Show("Ce numéro n'existe pas", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult dr = MessageBox.Show("Êtes vous sûr de vouloir supprimer ce stagiaire ?", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question); // Le MessageBox renvoie un résultat de type DialogueResult
                if (dr == DialogResult.Yes)
                {
                    bool c = Stagiaire.SupprimerStagiaire(int.Parse(txtInscription.Text));
                    if (c == true)
                        MessageBox.Show("Suppression effectuée.", "Message");
                    else
                        MessageBox.Show("Erreur inattendue lors de la suppression.", "Message");
                }
                else
                    this.Close();
            }

        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
