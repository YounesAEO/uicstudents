﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSTAG
{
    class Global
    {
        public static List<Stagiaire>lst = new List<Stagiaire>();

    }
}
