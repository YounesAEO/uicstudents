﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSTAG
{
    public partial class Liste_Stagiaires : Form
    {
        public Liste_Stagiaires()
        {
            InitializeComponent();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Liste_Stagiaires_Load(object sender, EventArgs e)
        {
            foreach (Stagiaire s in Global.lst)
            {
                txtListe.AppendText(s.Nom + " " + s.Prenom + " " + (s.Sexe).ToString() + " " + (s.Dn).ToString() + " " + (s.Module).ToString() + " " + (s.Note).ToString());
                txtListe.AppendText(Environment.NewLine);
            }
        }

        private void txtListe_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
