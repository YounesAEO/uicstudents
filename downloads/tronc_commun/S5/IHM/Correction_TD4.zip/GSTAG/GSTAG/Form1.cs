﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSTAG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void quitterTSMI_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ajouterTSMI_Click(object sender, EventArgs e)
        {
            Ajout_Stagiaire AS = new Ajout_Stagiaire();
            AS.Show();
        }

        private void fichierTSMI_Click(object sender, EventArgs e)
        {

        }

        private void listeDesStagiairesTSMI_Click(object sender, EventArgs e)
        {
            Liste_Stagiaires LS = new Liste_Stagiaires();
            LS.Show();
        }

        private void supprimerTSMI_Click(object sender, EventArgs e)
        {
            Supprimer_Stagiaire SS = new Supprimer_Stagiaire();
            SS.Show();
        }

        private void consulterTSMI_Click(object sender, EventArgs e)
        {
            Consultation C = new Consultation();
            C.Show();
        }

        private void listeDesStagiairesParModuleTSMI_Click(object sender, EventArgs e)
        {
            Liste_Module LM = new Liste_Module();
            LM.Show();
        }
    }
}
