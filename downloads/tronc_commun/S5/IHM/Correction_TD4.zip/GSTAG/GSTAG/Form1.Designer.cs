﻿namespace GSTAG
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fichierTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.quitterTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.stagiairesTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.supprimerTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.consulterTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.editionTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesStagiairesTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesStagiairesParModuleTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierTSMI,
            this.stagiairesTSMI,
            this.editionTSMI});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(505, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fichierTSMI
            // 
            this.fichierTSMI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quitterTSMI});
            this.fichierTSMI.Name = "fichierTSMI";
            this.fichierTSMI.Size = new System.Drawing.Size(54, 20);
            this.fichierTSMI.Text = "&Fichier";
            this.fichierTSMI.Click += new System.EventHandler(this.fichierTSMI_Click);
            // 
            // quitterTSMI
            // 
            this.quitterTSMI.Name = "quitterTSMI";
            this.quitterTSMI.Size = new System.Drawing.Size(152, 22);
            this.quitterTSMI.Text = "&Quitter";
            this.quitterTSMI.Click += new System.EventHandler(this.quitterTSMI_Click);
            // 
            // stagiairesTSMI
            // 
            this.stagiairesTSMI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ajouterTSMI,
            this.supprimerTSMI,
            this.consulterTSMI});
            this.stagiairesTSMI.Name = "stagiairesTSMI";
            this.stagiairesTSMI.Size = new System.Drawing.Size(69, 20);
            this.stagiairesTSMI.Text = "&Stagiaires";
            // 
            // ajouterTSMI
            // 
            this.ajouterTSMI.Name = "ajouterTSMI";
            this.ajouterTSMI.Size = new System.Drawing.Size(129, 22);
            this.ajouterTSMI.Text = "&Ajouter";
            this.ajouterTSMI.Click += new System.EventHandler(this.ajouterTSMI_Click);
            // 
            // supprimerTSMI
            // 
            this.supprimerTSMI.Name = "supprimerTSMI";
            this.supprimerTSMI.Size = new System.Drawing.Size(152, 22);
            this.supprimerTSMI.Text = "&Supprimer";
            this.supprimerTSMI.Click += new System.EventHandler(this.supprimerTSMI_Click);
            // 
            // consulterTSMI
            // 
            this.consulterTSMI.Name = "consulterTSMI";
            this.consulterTSMI.Size = new System.Drawing.Size(152, 22);
            this.consulterTSMI.Text = "&Consulter";
            this.consulterTSMI.Click += new System.EventHandler(this.consulterTSMI_Click);
            // 
            // editionTSMI
            // 
            this.editionTSMI.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listeDesStagiairesTSMI,
            this.listeDesStagiairesParModuleTSMI});
            this.editionTSMI.Name = "editionTSMI";
            this.editionTSMI.Size = new System.Drawing.Size(56, 20);
            this.editionTSMI.Text = "&Edition";
            // 
            // listeDesStagiairesTSMI
            // 
            this.listeDesStagiairesTSMI.Name = "listeDesStagiairesTSMI";
            this.listeDesStagiairesTSMI.Size = new System.Drawing.Size(235, 22);
            this.listeDesStagiairesTSMI.Text = "&Liste des stagiaires";
            this.listeDesStagiairesTSMI.Click += new System.EventHandler(this.listeDesStagiairesTSMI_Click);
            // 
            // listeDesStagiairesParModuleTSMI
            // 
            this.listeDesStagiairesParModuleTSMI.Name = "listeDesStagiairesParModuleTSMI";
            this.listeDesStagiairesParModuleTSMI.Size = new System.Drawing.Size(235, 22);
            this.listeDesStagiairesParModuleTSMI.Text = "&Liste des stagiaires par module";
            this.listeDesStagiairesParModuleTSMI.Click += new System.EventHandler(this.listeDesStagiairesParModuleTSMI_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 261);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Application GSTAG";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fichierTSMI;
        private System.Windows.Forms.ToolStripMenuItem quitterTSMI;
        private System.Windows.Forms.ToolStripMenuItem stagiairesTSMI;
        private System.Windows.Forms.ToolStripMenuItem ajouterTSMI;
        private System.Windows.Forms.ToolStripMenuItem supprimerTSMI;
        private System.Windows.Forms.ToolStripMenuItem consulterTSMI;
        private System.Windows.Forms.ToolStripMenuItem editionTSMI;
        private System.Windows.Forms.ToolStripMenuItem listeDesStagiairesTSMI;
        private System.Windows.Forms.ToolStripMenuItem listeDesStagiairesParModuleTSMI;
    }
}

