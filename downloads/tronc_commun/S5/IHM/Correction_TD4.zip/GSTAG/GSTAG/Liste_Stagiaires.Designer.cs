﻿namespace GSTAG
{
    partial class Liste_Stagiaires
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtListe = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtListe
            // 
            this.txtListe.Enabled = false;
            this.txtListe.Location = new System.Drawing.Point(13, 7);
            this.txtListe.Multiline = true;
            this.txtListe.Name = "txtListe";
            this.txtListe.Size = new System.Drawing.Size(390, 189);
            this.txtListe.TabIndex = 0;
            this.txtListe.TextChanged += new System.EventHandler(this.txtListe_TextChanged);
            // 
            // Liste_Stagiaires
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 204);
            this.Controls.Add(this.txtListe);
            this.Name = "Liste_Stagiaires";
            this.Text = "Liste de tous les stagiaires";
            this.Load += new System.EventHandler(this.Liste_Stagiaires_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtListe;
    }
}