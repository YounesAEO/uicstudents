﻿namespace GSTAG
{
    partial class Consultation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInscription = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.lblSexe = new System.Windows.Forms.Label();
            this.lblNaissance = new System.Windows.Forms.Label();
            this.lblModule = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.txtInscription = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.txtSexe = new System.Windows.Forms.TextBox();
            this.txtNaissance = new System.Windows.Forms.TextBox();
            this.txtModule = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.btnChercher = new System.Windows.Forms.Button();
            this.btnFermer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInscription
            // 
            this.lblInscription.AutoSize = true;
            this.lblInscription.Location = new System.Drawing.Point(28, 41);
            this.lblInscription.Name = "lblInscription";
            this.lblInscription.Size = new System.Drawing.Size(77, 13);
            this.lblInscription.TabIndex = 0;
            this.lblInscription.Text = "N° d\'inscription";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Location = new System.Drawing.Point(28, 74);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(29, 13);
            this.lblNom.TabIndex = 1;
            this.lblNom.Text = "Nom";
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.Location = new System.Drawing.Point(28, 111);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(43, 13);
            this.lblPrenom.TabIndex = 2;
            this.lblPrenom.Text = "Prénom";
            this.lblPrenom.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblSexe
            // 
            this.lblSexe.AutoSize = true;
            this.lblSexe.Location = new System.Drawing.Point(28, 148);
            this.lblSexe.Name = "lblSexe";
            this.lblSexe.Size = new System.Drawing.Size(31, 13);
            this.lblSexe.TabIndex = 3;
            this.lblSexe.Text = "Sexe";
            // 
            // lblNaissance
            // 
            this.lblNaissance.AutoSize = true;
            this.lblNaissance.Location = new System.Drawing.Point(28, 189);
            this.lblNaissance.Name = "lblNaissance";
            this.lblNaissance.Size = new System.Drawing.Size(96, 13);
            this.lblNaissance.TabIndex = 4;
            this.lblNaissance.Text = "Date de naissance";
            // 
            // lblModule
            // 
            this.lblModule.AutoSize = true;
            this.lblModule.Location = new System.Drawing.Point(28, 231);
            this.lblModule.Name = "lblModule";
            this.lblModule.Size = new System.Drawing.Size(42, 13);
            this.lblModule.TabIndex = 5;
            this.lblModule.Text = "Module";
            // 
            // lblNote
            // 
            this.lblNote.AutoSize = true;
            this.lblNote.Location = new System.Drawing.Point(28, 268);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(30, 13);
            this.lblNote.TabIndex = 6;
            this.lblNote.Text = "Note";
            // 
            // txtInscription
            // 
            this.txtInscription.Location = new System.Drawing.Point(147, 38);
            this.txtInscription.Name = "txtInscription";
            this.txtInscription.Size = new System.Drawing.Size(69, 20);
            this.txtInscription.TabIndex = 7;
            // 
            // txtNom
            // 
            this.txtNom.Enabled = false;
            this.txtNom.Location = new System.Drawing.Point(147, 71);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(87, 20);
            this.txtNom.TabIndex = 8;
            // 
            // txtPrenom
            // 
            this.txtPrenom.Enabled = false;
            this.txtPrenom.Location = new System.Drawing.Point(147, 108);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(87, 20);
            this.txtPrenom.TabIndex = 9;
            // 
            // txtSexe
            // 
            this.txtSexe.Enabled = false;
            this.txtSexe.Location = new System.Drawing.Point(147, 145);
            this.txtSexe.Name = "txtSexe";
            this.txtSexe.Size = new System.Drawing.Size(93, 20);
            this.txtSexe.TabIndex = 10;
            // 
            // txtNaissance
            // 
            this.txtNaissance.Enabled = false;
            this.txtNaissance.Location = new System.Drawing.Point(147, 186);
            this.txtNaissance.Name = "txtNaissance";
            this.txtNaissance.Size = new System.Drawing.Size(115, 20);
            this.txtNaissance.TabIndex = 11;
            // 
            // txtModule
            // 
            this.txtModule.Enabled = false;
            this.txtModule.Location = new System.Drawing.Point(147, 228);
            this.txtModule.Name = "txtModule";
            this.txtModule.Size = new System.Drawing.Size(93, 20);
            this.txtModule.TabIndex = 12;
            // 
            // txtNote
            // 
            this.txtNote.Enabled = false;
            this.txtNote.Location = new System.Drawing.Point(147, 265);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(87, 20);
            this.txtNote.TabIndex = 13;
            // 
            // btnChercher
            // 
            this.btnChercher.Location = new System.Drawing.Point(307, 35);
            this.btnChercher.Name = "btnChercher";
            this.btnChercher.Size = new System.Drawing.Size(76, 24);
            this.btnChercher.TabIndex = 14;
            this.btnChercher.Text = "Chercher";
            this.btnChercher.UseVisualStyleBackColor = true;
            this.btnChercher.Click += new System.EventHandler(this.btnChercher_Click);
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(307, 69);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(76, 22);
            this.btnFermer.TabIndex = 15;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            // 
            // Consultation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 335);
            this.Controls.Add(this.btnFermer);
            this.Controls.Add(this.btnChercher);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtModule);
            this.Controls.Add(this.txtNaissance);
            this.Controls.Add(this.txtSexe);
            this.Controls.Add(this.txtPrenom);
            this.Controls.Add(this.txtNom);
            this.Controls.Add(this.txtInscription);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.lblModule);
            this.Controls.Add(this.lblNaissance);
            this.Controls.Add(this.lblSexe);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.lblNom);
            this.Controls.Add(this.lblInscription);
            this.Name = "Consultation";
            this.Text = "Consultation";
            this.Load += new System.EventHandler(this.Consultation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInscription;
        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.Label lblSexe;
        private System.Windows.Forms.Label lblNaissance;
        private System.Windows.Forms.Label lblModule;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.TextBox txtInscription;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.TextBox txtSexe;
        private System.Windows.Forms.TextBox txtNaissance;
        private System.Windows.Forms.TextBox txtModule;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Button btnChercher;
        private System.Windows.Forms.Button btnFermer;
    }
}