﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GSTAG
{
    public partial class Consultation : Form
    {
        public Consultation()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Consultation_Load(object sender, EventArgs e)
        {

        }

        private void btnChercher_Click(object sender, EventArgs e)
        {
            Stagiaire S = Stagiaire.getStagiaireByPosition(int.Parse(txtInscription.Text));
            if (S == null)
                MessageBox.Show("Stagiaire inexistant", "Information");
            else
            {
                txtNom.Text = S.Nom;
                txtPrenom.Text = S.Prenom;
                txtSexe.Text = (S.Sexe).ToString();
                txtNaissance.Text = (S.Dn).ToString();
                txtModule.Text = (S.Module).ToString();
                txtNote.Text = (S.Note).ToString();
            }
        }
    }
}
