function [X,T,b] = Maillage2d(x1,x2,y1,y2,npx,npy)
% cr�e un maillage uniforme sur un domaine 
% rectangulaire [x1,x2]x[y1,y2]
%
% Entr�es:    
%   x1,x2,y1,y2:    coordonn�es des coins 
%   npx,npy:        nombres de noeuds dans chaque direction 
% Sorties:   
%          X:  table des coordonn�es
%          T:  table de connectivit�
%          b:  noeuds sur le bords
X = zeros((npx)*(npy),2);
% Nombre des �l�ments dans chaque direction
nx = npx-1; ny = npy-1;
%
hx = (x2-x1)/nx;
hy = (y2-y1)/ny;
xs = linspace(x1,x2,npx)'; 
unos = ones(npx,1);
%
% Coordonn�es des noeuds
%
yys = linspace(y1,y2,npy);
for i=1:npy
    ys = yys(i)*unos; 
    posi = (i-1)*(npx)+1:i*(npx); 
    X(posi,:)=[xs,ys];
end
% P1
% Connectivit�
T = zeros(nx*ny,3);
        for i=1:ny
            for j=1:nx
                ielem = 2*((i-1)*nx+j)-1;
                inode = (i-1)*(npx)+j;
                T(ielem,:) = [inode   inode+1   inode+(npx)];
                T(ielem+1,:) = [inode+1   inode+1+npx   inode+npx];
            end   
        end
%Noeuds sur le bord stock�es dans "b" comme suit (bas,gauche,droite,haut)
b=[1:npx,npx+1:npx:npx*npy,2*npx:npx:npx*npy,npx*npy-npx+2:npx*npy-1];
%
%
% P2
% A faire
%
end   


