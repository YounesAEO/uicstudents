clear all, close all, home
%------------------------
% Les entr�es
%------------------------
elem=input('Choisir elment(0 quadrilat�re, 1 triangle) :  ');
k=input('Choisir k pour type Pk :  ');
Ngauss=input('Choisir le nombre de points de Gauss :  ');
npx=input('Entrer nombre de points suivant (Ox) :  ');
npy=input('Entrer nombre de points suivant (Oy) :  ');
%------------------------------
% Les donn�es du maillage
x1=-2;x2=2;
y1=-1;y2=1;
%
% Second membre
f=@(x,y) -2*x^2-2*y^2+10;
% Solution exacte
ue=@(x,y) (x^2-4)*(y^2-1);
%--------------------------------
% maillage
[X,T,b] = Maillage2d(x1,x2,y1,y2,npx,npy);
% calcul de la solution
[Kb,Fb,U] = MEF2D(f,elem,k,X,T,b,Ngauss);
%------------------------------
% Affichage et comparaison
% Solution approch�e
figure(1); clf;
trisurf(T,X(:,1),X(:,2),0*X(:,1),U,'edgecolor','k','facecolor','interp');
view(2),axis([x1 x2 y1 y2]),axis equal,colorbar;
% Solution exacte
figure(2); clf;
uee=(X(:,1).^2-4).*(X(:,2).^2-1);
trisurf(T,X(:,1),X(:,2),0*X(:,1),uee,'edgecolor','k','facecolor','interp');
view(2),axis([x1 x2 y1 y2]),axis equal,colorbar;
%--------------------------------
% Calcul de l'erreur en norme L2
error_L2=norm(U-uee,2);
err_rela=error_L2\norm(uee,2);
fprintf('\t\t %4d \t\t %20.16e \t\t %20.16e\n\n', npx*npy,error_L2,err_rela);
fprintf('On a fini normalement\n');