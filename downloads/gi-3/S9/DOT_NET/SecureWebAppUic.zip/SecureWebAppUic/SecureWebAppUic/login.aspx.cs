﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using System;
using System.Web;
namespace SecureWebAppUic
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (User.Identity.IsAuthenticated)
                {
                    statutsMessage.Text = string.Format("Hello, {0}", User.Identity.GetUserName());
                    Sign_in.Visible = false;
                    Sign_Out.Visible = true;
                }else
                {
                    statutsMessage.Text = "";
                    Sign_in.Visible = true;
                    Sign_Out.Visible = false;
                }
            }
        }

        protected void Sign_in_Click(object sender, EventArgs e)
        {
            var userStore = new UserStore<IdentityUser>();
            var manager = new UserManager<IdentityUser>(userStore);
            //Search User
            var user = manager.Find(txtUserName.Text,txtPwd.Text);
            if (user!=null)
            {
                var authentication = HttpContext.Current.GetOwinContext().Authentication;
                var userIdentity = manager.CreateIdentity(user, DefaultAuthenticationTypes.ApplicationCookie);
                // Sign User
                authentication.SignIn(new AuthenticationProperties() { IsPersistent=false},userIdentity);
                Response.Redirect("login.aspx");
            }
        }

        //Sign Out
        protected void Button1_Click(object sender, EventArgs e)
        {
            var authenticationManager = HttpContext.Current.GetOwinContext().Authentication;
            authenticationManager.SignOut();
            Response.Redirect("login.aspx");
        }
    }
}