﻿
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Linq;
namespace SecureWebAppUic
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Create_User_Click(object sender, EventArgs e)
        {
            var userSTore = new UserStore<IdentityUser>();
            var manager = new UserManager<IdentityUser>(userSTore);
            var user = new IdentityUser() { UserName = txtUserName.Text};
            IdentityResult result = manager.Create(user, txtPwd.Text);
            if (result.Succeeded)
            {
                statutsMessage.Text = string.Format("User {0} has been succefully registered", user.UserName);
               
            }
            else
            {
                statutsMessage.Text = result.Errors.FirstOrDefault();
            }
        }
    }
}