﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BankingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Comptecourant cc = new Comptecourant(2000);
            cc.Proprietaire = "Nicolas";
            Compteepargne ce = new Compteepargne(0.02);
            ce.Proprietaire = "Nicolas";
            Comptecourant ccj = new Comptecourant(500);
            ccj.Proprietaire = "Jeremie";
            cc.Crediter(100);
            cc.Debiter(50);
            ce.Crediter(20, cc);
            ce.Crediter(100);
            cc.Crediter(20, ce);
            ccj.Debiter(500);
            cc.Crediter(200, ccj);
            Console.WriteLine("Solde Compte Courrant de {0}:{1}", cc.Proprietaire, cc.Solde);
            Console.WriteLine("Solde Compte epargne de {0}:{1}", ce.Proprietaire, ce.Solde);
            Console.WriteLine("Solde Compte Courrant de {0}:{1}", ccj.Proprietaire, ccj.Solde);
            cc.AfficherResume();
            ce.AfficherResume();
            Console.ReadKey();
        }
    }
}

