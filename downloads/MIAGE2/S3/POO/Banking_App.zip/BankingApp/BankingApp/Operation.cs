﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BankingApp
{
    class Operation
    {
        private decimal montant;
        private Typeoperation toperation;

        public decimal Montant
        {
            get { return montant; }
            set { montant = value; }
        }
        public Typeoperation Toperation
        {
            get { return toperation; }
            set { toperation = value; }
        }





    }
}