﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BankingApp
{
    public abstract class Compte
    {
        private decimal solde;
        private string proprietaire;
        private List<Operation> lstops;

        public Compte()
        {
            lstops = new List<Operation>();
        }
        public virtual decimal Solde
        {
            get
            {
                decimal s = 0;
                foreach (Operation op in lstops)
                {
                    if (op.Toperation == Typeoperation.credit)
                        s += op.Montant;
                    else
                        s -= op.Montant;
                }
                return s;
            }
        }
        public string Proprietaire
        {
            get { return proprietaire; }
            set { proprietaire = value; }
        }
        public void Crediter(decimal mt)
        {
            Operation op = new Operation();
            op.Toperation = Typeoperation.credit;
            op.Montant = mt;
            lstops.Add(op);
        }
        public void Debiter(decimal mt)
        {
            Operation op = new Operation();
            op.Toperation = Typeoperation.debit;
            op.Montant = mt;
            lstops.Add(op);
        }
        public void Crediter(decimal mt, Compte cpt)
        {
            cpt.Debiter(mt);
            Crediter(mt);
        }
        public void Debiter(decimal mt, Compte cpt)
        {
            Debiter(mt);
            cpt.Crediter(mt);
        }
        public void AfficherOperations()
        {
            if (lstops.Count == 0)
                Console.WriteLine("Aucune operation n'a etait realise ");
            else
                Console.WriteLine("Operations:");
            foreach (Operation op in lstops)
            {
                if (op.Toperation == Typeoperation.credit)
                    Console.WriteLine("\t+{0}", op.Montant);
                else
                    Console.WriteLine("\t-{0}", op.Montant);
            }
        }
        public abstract void AfficherResume();
    }
}