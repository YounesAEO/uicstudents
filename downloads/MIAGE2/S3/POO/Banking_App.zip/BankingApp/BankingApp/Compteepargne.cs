﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BankingApp
{
    class Compteepargne : Compte
    {
        private double tauxAb;

        public double TauxAb
        {
            get { return tauxAb; }
        }
        public Compteepargne(double ta) : base()
        {
            tauxAb = ta;
        }
        public override decimal Solde
        {
            get
            {
                return base.Solde * (decimal)(1 + tauxAb);
            }
        }
        public override void AfficherResume()
        {
            Console.WriteLine("Resume du compte de {0}", base.Proprietaire);
            Console.WriteLine("###########################################");
            Console.WriteLine("Compte  epargne  entreprise de:{0} ", base.Proprietaire);
            Console.WriteLine("\t Solde:{0}", Solde);
            Console.WriteLine("\t taux:{0}", tauxAb);
            AfficherOperations();
            Console.WriteLine("###########################################");
        }
    }
}

