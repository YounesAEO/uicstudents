﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BankingApp
{
    class Comptecourant : Compte
    {
        private decimal decouvert;
        public decimal Decouvert
        {
            get { return decouvert; }
        }
        public Comptecourant(decimal dc) : base()
        {
            decouvert = dc;
        }
        public override void AfficherResume()
        {
            Console.WriteLine("Resume du compte de {0}", base.Proprietaire);
            Console.WriteLine("********************************************");
            Console.WriteLine("Compte courant de {0}", base.Proprietaire);
            Console.WriteLine("\t Solde:{0}", base.Solde);
            Console.WriteLine("\t Decouvert autorise:{0}", decouvert);
            AfficherOperations();
            Console.WriteLine("********************************************");

        }
    }
}